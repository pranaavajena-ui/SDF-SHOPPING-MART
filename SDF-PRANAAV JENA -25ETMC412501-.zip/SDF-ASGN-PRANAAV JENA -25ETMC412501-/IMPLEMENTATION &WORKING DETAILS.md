# Campus Basket

**Software Development Fundamentals · CSC203B**  
**Student:** Pranaav Jena · **Roll number:** 25ETMC412501  
**Course:** B.Tech Mathematics and Computing · **Batch:** 2025–2029

Campus Basket is a small, student-focused online shopping prototype. It uses a sample shelf of six campus essentials so the shopping flow stays easy to understand and demonstrate.

> **Scenario check:** the supplied assignment sheet names flight reservation requirements, while the student's handwritten requirements describe an online shopping system. This project follows the online shopping scenario confirmed by the student. Please confirm with the course leader that this is the accepted scenario before submitting.

## Run it

1. Extract this project folder.
2. Open `index.html` in a recent browser. If the browser blocks local storage for a file, open a terminal in this folder and run `python3 -m http.server 8000`, then visit `http://localhost:8000`.
3. The app starts with a demo account: `student@campus.test` / `Campus123`.
4. Use **Switch account** to sign in or create another browser-local account.

The app uses only HTML, CSS and JavaScript, with no package installation. Account, basket, orders and reviews are stored in the browser's `localStorage`. Clearing the browser's site data resets the demonstration.

## What works in the prototype

- Search and category filter over six sample products.
- Add, remove and change basket quantities, with stock checks.
- Checkout with an address, a demo payment choice and a 5% demo tax.
- Order history, status display, cancellation while the order is **Placed**, and a recorded demo refund.
- Profile editing, a locally generated one-time reset code, a fixed FAQ helper, a support-request note and feedback.

## Important limits

This is a classroom prototype. No real email or SMS is sent, no payment is collected, no courier status is fetched and no human support agent is connected. The reset code is shown in the app. Browser data is not encrypted or backed up; do not use real account details or passwords. The “AI support” requirement is represented by a fixed FAQ helper rather than an AI service.

## Logic checks

Run `node qa/run_checks.js` to repeat the JavaScript business-logic checks. The checks load the actual script with a small DOM substitute; they do not replace a browser-based click-through. See `qa/test_results.txt` for the results and scope.

## Project files

- `index.html` — complete app source.
- `assets/` — design diagrams and interface layout preview used by the report.
- `qa/run_checks.js` — lightweight logic-check script.
- `qa/test_results.txt` — observed check results and scope.
