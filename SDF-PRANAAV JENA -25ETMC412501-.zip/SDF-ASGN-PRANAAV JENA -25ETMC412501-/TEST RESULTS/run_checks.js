// Lightweight checks of the actual app script with a small DOM substitute.
// The interactive browser was unavailable in this workspace, so these do not
// replace a final click-through in Chrome/Firefox on the student's computer.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const elements={};
function el(id){return elements[id] ||= {innerHTML:'',textContent:'',value:'',classList:{add(){},remove(){},toggle(){}},addEventListener(){},querySelector(){return {addEventListener(){}}}}}
const memory={};
const ctx={document:{getElementById:el,querySelectorAll(){return []}},localStorage:{getItem:k=>memory[k]||null,setItem:(k,v)=>{memory[k]=v}},setTimeout:()=>1,clearTimeout(){},Date,Math,console};
ctx.el=el;vm.createContext(ctx);vm.runInContext(script,ctx);
const check=(label,fn)=>{fn();console.log('PASS: '+label)};
check('six student-focused products are present',()=>assert.strictEqual(vm.runInContext('products.length',ctx),6));
check('password rule accepts a basic valid example and rejects a weak one',()=>{assert.strictEqual(vm.runInContext("validPassword('Campus123')",ctx),true);assert.strictEqual(vm.runInContext("validPassword('short')",ctx),false)});
check('search and category filter narrow the shelf',()=>{el('search').value='notebook';el('category').value='';vm.runInContext('filter()',ctx);assert.match(el('productGrid').innerHTML,/Graph notebook/);assert.doesNotMatch(el('productGrid').innerHTML,/USB-C cable/)});
check('basket quantity is added and respects stock',()=>{vm.runInContext("changeCart('NB01',1)",ctx);assert.strictEqual(vm.runInContext('db.cart.NB01',ctx),1);vm.runInContext('db.cart.NB01=12; changeCart(\'NB01\',1)',ctx);assert.strictEqual(vm.runInContext('db.cart.NB01',ctx),12)});
check('valid checkout creates a 5%-tax order and reduces stock',()=>{vm.runInContext("db.cart={NB01:1}; el('shipAddress').value='Campus hostel, Bengaluru'; el('payMode').value='UPI (demo)'; placeOrder()",ctx);assert.strictEqual(vm.runInContext('db.orders.length',ctx),1);assert.strictEqual(vm.runInContext('db.orders[0].total',ctx),89.25);assert.strictEqual(vm.runInContext("products.find(p=>p.id==='NB01').stock",ctx),11)});
check('a newly placed order can be cancelled and a demo refund is recorded',()=>{ctx.modal=(title,body,label,submit)=>submit();vm.runInContext("cancelOrder('CB-0001')",ctx);assert.strictEqual(vm.runInContext("db.orders[0].status",ctx),'Cancelled');assert.strictEqual(vm.runInContext('db.orders[0].refund',ctx),89.25);assert.strictEqual(vm.runInContext("products.find(p=>p.id==='NB01').stock",ctx),12)});
check('profile rejects an invalid phone number and accepts a 10-digit one',()=>{el('profileName').value='Pranaav Jena';el('profilePhone').value='123';el('profileAddress').value='';vm.runInContext('saveProfile()',ctx);assert.strictEqual(vm.runInContext("user().phone",ctx),'');el('profilePhone').value='9876543210';vm.runInContext('saveProfile()',ctx);assert.strictEqual(vm.runInContext("user().phone",ctx),'9876543210')});
check('feedback is added to the signed-in account',()=>{el('reviewText').value='Easy to use for a first try.';el('rating').value='5';vm.runInContext('sendReview()',ctx);assert.strictEqual(vm.runInContext('db.reviews.length',ctx),1);assert.strictEqual(vm.runInContext('db.reviews[0].stars',ctx),5)});
fs.writeFileSync(path.join(__dirname,'test_results.txt'), `Campus Basket logic checks

PASS: six student-focused products are present
PASS: password rule accepts a basic valid example and rejects a weak one
PASS: search and category filter narrow the shelf
PASS: basket quantity is added and respects stock
PASS: valid checkout creates a 5%-tax order and reduces stock
PASS: a newly placed order can be cancelled and a demo refund is recorded
PASS: profile rejects an invalid phone number and accepts a 10-digit one
PASS: feedback is added to the signed-in account

Scope: JavaScript logic checks run in Node with a small DOM substitute. A full visual/browser click-through should still be done on the student's computer.
`);
